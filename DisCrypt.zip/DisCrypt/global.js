document.addEventListener("DOMContentLoaded", () => {
    const phase = document.body.dataset.phase;
    console.log(`Fase atual: ${phase}`);
});
