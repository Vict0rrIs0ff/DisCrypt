const specificWord = document.getElementById("specific-word");

specificWord.addEventListener("click", () => {
    window.location.href = "fase1.html";
});
